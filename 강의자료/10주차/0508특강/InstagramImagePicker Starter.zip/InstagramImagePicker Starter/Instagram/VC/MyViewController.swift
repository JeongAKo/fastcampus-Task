//
//  MyViewController.swift
//  Instagram
//
//  Created by Wi on 03/05/2019.
//  Copyright © 2019 Wi. All rights reserved.
//

import UIKit


// 마이페이지
class MyViewController: UITableViewController {
    
    
    let picker = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configure()
    }
    override func viewWillAppear(_ animated: Bool) {
        tableView.reloadData()
    }
    
    
    
    // MARK: Configure
    
    func configure(){
        
        // imagePicker
        picker.delegate = self
        
        
        // noti
        NotificationCenter.default.addObserver(self, selector: #selector(nickNameChange), name: Notification.Name("nickNameChange"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(profileImageChange), name: Notification.Name("profileImageView"), object: nil)
        
        // tableView
        tableView.register(UINib(nibName: "MyViewTableViewCell", bundle: nil), forCellReuseIdentifier: "myView")
        tableView.separatorColor = .clear
        
    }
    
    // MARK: TableView
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // 미리 만들어둔 셀
        let cell = tableView.dequeueReusableCell(withIdentifier: "myView", for: indexPath) as! MyViewTableViewCell
        cell.selectionStyle = .none
        
        return cell
    }
    
    // MARK: Action
    // 닉네임 수정버튼이 눌렸을때 불릴 함수
    @objc private func nickNameChange(_ sender: Notification){
        guard let nickname = sender.userInfo?["nickName"] as? String else {return}
        
    }
    // 프로필 이미지뷰를 눌렀을때 불릴 함수
    @objc private func profileImageChange(_ sender: Notification){
        
    }
    
    // MARK: other func
    // 2
    private func createOkAlert(title: String, message: String){
        
    }
    // 1
    private func createSheetAlert(title: String, message: String){
        
    }
}

// MARK: - UIImagePicker

extension MyViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true, completion: nil)
    }
}
