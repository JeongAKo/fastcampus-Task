//
//  ViewController.swift
//  FastcampusLogin
//
//  Created by Daisy on 05/04/2019.
//  Copyright © 2019 고정아. All rights reserved.
//

import UIKit

class Student {
    let name: String
    let password: String
    
    init(name: String, password: String) {
        self.name = name
        self.password = password
    }
}

class ViewController: UIViewController {
    
    let id = "acb"
    let pw = 123
    var popUpCheck = false
    
    
    // 학생정보
    let student: [Student] = [
        Student(name: "개구리", password: "flog"),
        Student(name: "곰돌이", password: "bear"),
        Student(name: "희망이", password: "dog"),
    ]
    
    
    
    @IBOutlet weak var someView: UIView!
    @IBOutlet weak var idTextField: UITextField!
    @IBOutlet weak var pwTextField: UITextField!
    
    @IBOutlet weak var mailPic: UIImageView!
    @IBOutlet weak var lockPic: UIImageView!
    
    
    
    @IBAction func editingDidBegin(_ sender: Any) {
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        idTextField.delegate = self
        pwTextField.delegate = self
    }
    
    @IBAction func pushSigninButton(_ sender: Any) {
        performSegue(withIdentifier: "넘어가", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: self)
        guard let vc = segue.destination as? SecondViewController else { return }
    }
    
    @IBAction func unwindToFirst(_ unwindSegue: UIStoryboardSegue) {
        idTextField.text = nil
        
    }
    
    
}

extension ViewController: UITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        guard popUpCheck  == false else { return }
        UIView.animate(withDuration: 0.5) {
            self.someView.frame.origin.y -= 150
            self.popUpCheck = true
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        UIView.animate(withDuration: 0.5) {
            self.someView.frame.origin.y += 150
        }
        popUpCheck = false
        return true
    }

}




